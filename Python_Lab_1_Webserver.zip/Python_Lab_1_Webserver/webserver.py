"""Lab 1: sequential TCP web server. Run with: python webserver.py"""
from socket import AF_INET, SOCK_STREAM, SOL_SOCKET, SO_REUSEADDR, socket
from pathlib import Path
from urllib.parse import unquote, urlsplit
import mimetypes

HOST = "0.0.0.0"
PORT = 6789
ROOT = Path(__file__).resolve().parent


def respond(connection, status, body, content_type="text/html; charset=utf-8"):
    # A blank CRLF line separates the HTTP headers from the body.
    header = (
        f"HTTP/1.1 {status}\r\n"
        f"Content-Type: {content_type}\r\n"
        f"Content-Length: {len(body)}\r\n"
        "Connection: close\r\n\r\n"
    )
    connection.sendall(header.encode("ascii") + body)


def main():
    with socket(AF_INET, SOCK_STREAM) as serverSocket:
        serverSocket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
        serverSocket.bind((HOST, PORT))
        serverSocket.listen(1)
        print(f"Server listening on port {PORT}. Press Ctrl+C to stop.", flush=True)
        while True:
            print("Ready to serve...", flush=True)
            connectionSocket, addr = serverSocket.accept()
            # This connection finishes before another connection is accepted.
            with connectionSocket:
                connectionSocket.settimeout(10)
                try:
                    message = b""
                    while b"\r\n\r\n" not in message:
                        chunk = connectionSocket.recv(1024)
                        if not chunk:
                            break
                        message += chunk
                        if len(message) > 16384:
                            break
                    if not message:
                        continue
                    parts = message.split(b"\r\n", 1)[0].decode("iso-8859-1").split()
                    if len(parts) != 3 or b"\r\n\r\n" not in message:
                        respond(connectionSocket, "400 Bad Request", b"<h1>400 Bad Request</h1>")
                        continue
                    method, target, version = parts
                    if method != "GET":
                        respond(connectionSocket, "501 Not Implemented", b"<h1>Only GET is supported</h1>")
                        continue
                    filename = unquote(urlsplit(target).path).lstrip("/")
                    file_path = (ROOT / filename).resolve()
                    # Keep file requests inside the lab folder.
                    if ROOT not in file_path.parents or not file_path.is_file():
                        raise FileNotFoundError(filename)
                    outputdata = file_path.read_bytes()
                    content_type = mimetypes.guess_type(str(file_path))[0] or "application/octet-stream"
                    if content_type.startswith("text/"):
                        content_type += "; charset=utf-8"
                    respond(connectionSocket, "200 OK", outputdata, content_type)
                    print(f"{addr[0]} GET {target} -> 200 OK", flush=True)
                except (FileNotFoundError, PermissionError, IsADirectoryError):
                    respond(connectionSocket, "404 Not Found", b"<!doctype html><html><body><h1>404 Not Found</h1><p>The requested file was not found on this server.</p></body></html>")
                    print("404 Not Found", flush=True)
                except (TimeoutError, ConnectionError):
                    print("Client timed out or disconnected.", flush=True)
                except OSError as error:
                    print(f"Connection/file error: {error}", flush=True)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nServer stopped.")
